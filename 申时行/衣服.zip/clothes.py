# -*- coding: utf-8 -*-
"""
Created on 2022-02-22 10:44:09
---------
@summary:
---------
@author: Administrator
"""

import feapder
import pandas as pd


class Clothes(feapder.AirSpider):
    def __init__(self):
        super().__init__()
        self.clothes_list = []


    def start_requests(self):
        yield feapder.Request("https://www.amazon.com/s?k=Marvel+Shirt&s=date-desc-rank")

    def download_midware(self, request):
        request.headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 5.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/36.0.1985.67 Safari/537.36',
            'cookie': 'session-id-time=2082787201l; i18n-prefs=USD; sp-cdn="L5Z9:CN"; session-id=136-2092857-3811368; lc-main=zh_CN; ubid-main=133-4439972-5146242; session-token=+WILj4R8CUElDDp577BvchmNAuakD8bnJiifRSh8/M5tqRFrb1ECUbm7Eu7K/33Ofq7DVTkqGOXH1wgRL5unRRrUmPQMoi6q3o6lWkrtfMmkIF7AAV47GM7A69tmV/e/dStFUowY3YPIIYnraqQaYVcjBVOhJRanoiv5LPaqdHj2OiQlT1yQEoxxqDHwxaAl'
        }
        return request

    def parse(self, request, response):
        div_list = response.xpath(
            '//*[@id="search"]/div[1]/div[1]/div/span[3]/div[2]/div[not(contains(@class,"AdHolder"))]')
        for div in div_list:
            name = div.xpath('./div/div/div/div/div[2]/div[1]/h2/a/span/text()').extract_first()
            price = div.xpath('./div/div/div/div/div[2]/div/div/a/span/span[2]//text()').extract()
            price = ''.join(price)
            if not price:
                price = '未标示价格'
            img = div.xpath('./div/div/div/div/div[1]/span/a/div/img/@src').extract_first()
            # 如果名称不为空
            if name:
                self.clothes_list.append([name,price,img])

        href = response.xpath('//a[contains(@class,"s-pagination-next")]/@href').extract_first()
        if href is not None:
            yield feapder.Request(url=href, callback=self.parse)



    def end_callback(self):
        clothes_csv = pd.DataFrame(self.clothes_list,columns=['name','price','img'])
        clothes_csv.to_csv('clothes.csv')


if __name__ == "__main__":
    Clothes().start()
